package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {
	
	Contact contact = new Contact("123", "Justin", "Brown", "1234567891", "3014 Pleasant Dr");

	@Test
	void getUniqueContactID() {
		assertEquals("123", contact.getUniqueContactID());
	}
	
	@Test
	void getFirstName() {
		assertEquals("Justin", contact.getFirstName());
	}
	
	@Test
	void getLastName() {
		assertEquals("Brown", contact.getLastName());
	}
	
	@Test
	void getNumber() {
		assertEquals("1234567891", contact.getNumber());
	}
	
	@Test
	void getAddress() {
		assertEquals("3014 Pleasant Dr", contact.getAddress());
	}

}
