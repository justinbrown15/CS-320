package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	Contact contact = new Contact("123", "Justin", "Brown", "1234567891", "3014 Pleasant Dr");
	
	ContactService service = new ContactService();
	
	@Test
	void testAddContacts() {
		assertEquals(true, service.addContacts(contact));
	}
	
	@Test
	void testDeleteContacts() {
		service.addContacts(contact);
		assertEquals(true, service.removeContacts("123"));
	}
	
	@Test
	void testUpdateContactFields() {
		service.addContacts(contact);
		assertEquals(true, service.updateContactFields("123", "Billy", "Bob", "1111111111", "123 Paradise Blvd"));
	}

}
