package contact;

public class Contact {
	String uniqueContactID;
	String firstName;
	String lastName;
	String Number;
	String Address;
	
	//constructor with the required fields
	public Contact(String uniqueContactID, String firstName, String lastName, String Number, String Address) {
		this.uniqueContactID = uniqueContactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
		this.Address = Address;
		
	}
	//auto-generate getters and setters via source-> generate getters and setters

	public String getUniqueContactID() {
		return uniqueContactID;
	}

	public void setUniqueContactID(String uniqueContactID) {
		this.uniqueContactID = uniqueContactID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNumber() {
		return Number;
	}

	public void setNumber(String number) {
		Number = number;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

}
