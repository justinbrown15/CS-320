package contact;
import java.util.ArrayList;


public class ContactService {

	ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	//need to be able to add contacts with unique ID
	public boolean addContacts(Contact contact) {
		boolean uniqueID = false;
		for(Contact con: contacts) {
			if(con.equals(contact)) {
				uniqueID = true;
			}
		}
		if(!uniqueID) {
			contacts.add(contact);
			return true;
		} 
		else {
			return false;
		}
	}
	//need to be able to delete contacts per contact ID
	public boolean removeContacts(String uniqueContactID) {
		for(Contact con: contacts) {
			if(con.getUniqueContactID().equals(uniqueContactID)) {
				contacts.remove(con);
				return true;
			} 
			
		}
		return false;
	}
	//need to be able to update contact fields per contact ID: first name, last name, number, address. These all shall not be null
	public boolean updateContactFields(String uniqueContactID, String firstName, String LastName, String Number, String Address) {
		for(Contact con: contacts) {
			if(con.getUniqueContactID().equals(uniqueContactID)) {
				if(!firstName.equals("") && !(firstName.length() > 10)){
					con.setFirstName(firstName);
				}
				if(!LastName.equals("") && !(LastName.length() > 10)){
					con.setLastName(LastName);
				}
				if(!Number.equals("") && (Number.length() == 10)){
					con.setNumber(Number);
				}
				if(!Address.equals("") && !(Address.length() > 30)){
					con.setAddress(Address);
				}
				return true;
			}
		}
		return false;
	}
}
